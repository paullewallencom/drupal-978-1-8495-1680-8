(function ($) {
  
}(jQuery));

(function ($) {

  Drupal.behaviors.d7dev_theme = {
    attach: function (context, settings) {
      //$( "div.view-id-recipes_by_cuisine div.view-content" ).tabs();
    }
  };

}(jQuery));